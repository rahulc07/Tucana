# Keyword parameters passed to publish_file.
reader_name = "standalone"
parser_name = "rst"

# Settings.
settings_overrides['sectsubtitle_xform'] = 1
settings_overrides['syntax_highlight'] = 'none'
